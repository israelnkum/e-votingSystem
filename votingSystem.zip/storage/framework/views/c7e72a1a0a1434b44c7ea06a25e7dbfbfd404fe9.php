<?php $__env->startSection('content'); ?>

    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Cast Voting</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Cast Voting</li>
            </ol>
        </div>
        <div class="col-md-7 col-4 align-self-center">
            <div class="d-flex m-t-10 justify-content-end">
                <div class="d-flex m-r-20 m-l-10 hidden-md-down">
                    <div class="chart-text m-r-10">
                        <h6 class="m-b-0"><small>THIS MONTH</small></h6>
                        <h4 class="m-t-0 text-info">$58,356</h4></div>
                    <div class="spark-chart">
                        <div id="monthchart"></div>
                    </div>
                </div>
                <div class="d-flex m-r-20 m-l-10 hidden-md-down">
                    <div class="chart-text m-r-10">
                        <h6 class="m-b-0"><small>LAST MONTH</small></h6>
                        <h4 class="m-t-0 text-primary">$48,356</h4></div>
                    <div class="spark-chart">
                        <div id="lastmonthchart"></div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Bread crumb and right sidebar toggle -->
                    <!-- ============================================================== -->
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Validation wizard -->
    <div class="row">
        <div class="col-md-12 bg-white">
            <div class="row" id="validation">
                <div class="col-md-6 offset-md-3 col-sm-12">
                    <div class="wizard-content">
                        <div class="card-body bg-transparent">
                            <form action="<?php echo e(route('cast-voting.store')); ?>" method="POST" class="validation-wizard wizard-circle">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position => $candidates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h5 class="text-danger"><?php echo e($candidates[0]->position->name); ?></h5>
                                    <section>
                                        <div class="table-responsive">
                                            <table  class="table">
                                                <tbody>
                                                <?php
                                                    $kojoCount = 0;
                                                ?>
                                                <tr>
                                                    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td>
                                                            <div class="card">
                                                                <div class="card-body text-center">
                                                                    <img src="<?php echo e(asset('nominee_img/'.$candidate->image)); ?>" class="img-circle" width="150" height="150" />
                                                                    <h4 class="card-title m-t-10"><?php echo e($candidate['last_name']." ".$candidate['other_name']." ".$candidate['first_name']); ?></h4>
                                                                    <h6 class="card-subtitle text-danger font-16"><?php echo e($candidate->position->name); ?></h6>
                                                                    <div class="form-group row text-center">
                                                                        <div class="col-md-12 col-sm-12">
                                                                            <div class="m-b-10">
                                                                                <div id="checkbox_group">
                                                                                    <?php if(count($candidates) == 1): ?>
                                                                                        <label class="inline custom-control custom-checkbox block">
                                                                                            <input type="checkbox" value="<?php echo e($candidate->id); ?>" required name="voteCasted[]" id="<?php echo e($candidate->position->id); ?>" class="custom-control-input cbox<?php echo e($candidate->position->id); ?>">
                                                                                            <span class="custom-control-label ml-0">Yes</span>
                                                                                        </label>

                                                                                        <label class="inline custom-control custom-checkbox block">
                                                                                            <input type="checkbox" value="<?php echo e(0); ?>" required name="voteCasted[]" id="<?php echo e($candidate->position->id); ?>" class="custom-control-input cbox<?php echo e($candidate->position->id); ?>">
                                                                                            <span class="custom-control-label ml-0">No</span>
                                                                                        </label>

                                                                                    <?php else: ?>
                                                                                        <label class="inline custom-control custom-checkbox block">
                                                                                            <input type="checkbox" value="<?php echo e($candidate->id); ?>" required name="voteCasted[]" id="<?php echo e($candidate->position->id); ?>" class="custom-control-input cbox<?php echo e($candidate->position->id); ?>">
                                                                                            <span class="custom-control-label ml-0">Vote</span>
                                                                                        </label>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <?php
                                                            $kojoCount++;
                                                        ?>
                                                        <?php if($kojoCount >0): ?>

                                                            <?php
                                                                $kojoCount = 0;
                                                            ?>
                                                </tr>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
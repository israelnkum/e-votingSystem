<!DOCTYPE html><html class="no-js" lang="en-US" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width"><link rel="pingback" href="https://wrappixel.com/xmlrpc.php" /><title>Nothing found for  Demos Admin Templates Material Pro Assets Plugins Jquery Ascolorpicker Master Libs Jquery Asgradient Js</title> <script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script> <link rel='dns-prefetch' href='//cdnjs.cloudflare.com' /><link rel='dns-prefetch' href='//www.paypalobjects.com' /><link rel='dns-prefetch' href='//fonts.googleapis.com' /><link rel="alternate" type="application/rss+xml" title="Wrappixel &raquo; Feed" href="https://wrappixel.com/feed/" /><link rel="alternate" type="application/rss+xml" title="Wrappixel &raquo; Comments Feed" href="https://wrappixel.com/comments/feed/" /><link rel='stylesheet' id='contact-form-7-css'  href='https://wrappixel.com/wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' /><link rel='stylesheet' id='edd-styles-css'  href='https://wrappixel.com/wp-content/themes/checkout/edd_templates/edd.css' type='text/css' media='all' /><link rel='stylesheet' id='gglcptch-css'  href='https://wrappixel.com/wp-content/plugins/google-captcha/css/gglcptch.css' type='text/css' media='all' /><link rel='stylesheet' id='edd-free-downloads-modal-css'  href='https://wrappixel.com/wp-content/plugins/edd-free-downloads-master/assets/js/jBox/Source/jBox.css' type='text/css' media='all' /><link rel='stylesheet' id='edd-free-downloads-css'  href='https://wrappixel.com/wp-content/plugins/edd-free-downloads-master/assets/css/style.css' type='text/css' media='all' /><link rel='stylesheet' id='dashicons-css'  href='https://wrappixel.com/wp-includes/css/dashicons.min.css' type='text/css' media='all' /><link rel='stylesheet' id='edd-reviews-css'  href='https://wrappixel.com/wp-content/plugins/edd-reviews/assets/css/edd-reviews.min.css' type='text/css' media='all' /><link rel='stylesheet' id='edd-slg-public-style-css'  href='https://wrappixel.com/wp-content/plugins/edd-social-login/includes/css/style-public.css' type='text/css' media='all' /><link rel='stylesheet' id='checkout-style-css'  href='https://wrappixel.com/wp-content/themes/checkout-child-latest/style.css' type='text/css' media='all' /><link rel='stylesheet' id='checkout-fontawesome-css-css'  href='https://wrappixel.com/wp-content/themes/checkout/inc/fonts/fontawesome/css/font-awesome.css' type='text/css' media='all' /><link rel='stylesheet' id='google-font-css'  href='//fonts.googleapis.com/css?family=Rubik%3A300%2C400%2C600%2C700%2C400italic&#038;subset=latin%2Clatin-ext%2Ccyrillic%2Ccyrillic-ext%2Cgreek%2Cgreek-ext%2Cvietnamese' type='text/css' media='all' /><link rel='stylesheet' id='bootstrap-css'  href='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/css/bootstrap.min.css' type='text/css' media='all' /><link rel='stylesheet' id='owl-carousel-css'  href='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/css/owl.css' type='text/css' media='all' /><link rel='stylesheet' id='child-style-css'  href='https://wrappixel.com/wp-content/themes/checkout-child-latest/style.css' type='text/css' media='all' /><link rel='https://api.w.org/' href='https://wrappixel.com/wp-json/' /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://wrappixel.com/xmlrpc.php?rsd" /><link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://wrappixel.com/wp-includes/wlwmanifest.xml" /><meta name="generator" content="WordPress 4.9.7" /><meta name="generator" content="Easy Digital Downloads v2.9.9" /><style>.edd_download{float:left;}.edd_download_columns_1 .edd_download{width: 100%;}.edd_download_columns_2 .edd_download{width:50%;}.edd_download_columns_0 .edd_download,.edd_download_columns_3 .edd_download{width:33%;}.edd_download_columns_4 .edd_download{width:25%;}.edd_download_columns_5 .edd_download{width:20%;}.edd_download_columns_6 .edd_download{width:16.6%;}</style> <script type="text/javascript">var AFFWP = AFFWP || {};
AFFWP.referral_var = 'ref';
AFFWP.expiration = 1;
AFFWP.debug = 0;

AFFWP.referral_credit_last = 0;</script> <style type="text/css">/* Link color */
a,
    #comments .bypostauthor .fn:before {
    color: #f04e35;
}

/* Header title color */
.hero-title h2 {
    color: #231f20;
}

/* Header subtitle color */
.hero-title h3,
.hero-title p {
    color: #231f20;
}

/* Main navigation link color */
.main-navigation a,
.site-description {
    color: #231f20;
}

/* Footer navigation link color */
.site-footer a,
.site-footer .copyright a,
.site-footer,
.widget .menu li a:before {
    color: #231f20;
}

/* EDD related colors */
#content .fes-vendor-menu ul li.active,
#content .fes-vendor-menu ul li:hover {
    border-top-color: #f04e35;
}

/* Background color for various elements throughout the theme */
input[type="submit"],
.button,
.post-content .button,
.cta-button,
#content .contact-form input[type="submit"],
    #commentform #submit,
.portfolio-wrapper .rslides_nav:hover,
.quantities-enabled .single-quantity-mode:not(.free-download) [id^="edd_purchase"] .edd_purchase_submit_wrapper,
[id^="edd_purchase"] .edd-add-to-cart:not(.download-meta-purchase),
#mailbag_mailchimp .mailbag-input .button,
    input[type=checkbox]:checked,
    input[type=radio]:checked,
    #content input[type=submit].edd-submit,
.download-meta .edd_go_to_checkout,
.page-numbers.current,
.page-numbers:hover,
.rslides_nav:hover,
.main-navigation .edd_checkout,
    #searchform #searchsubmit,
.edd-cart-added-alert,
.quantities-enabled [id^="edd_purchase"] .edd_purchase_submit_wrapper,
.post-password-form input[type="submit"] {
    background: #f04e35;
}

/* Background color for the header and footer */
.site-header, .site-footer {
    background-color: #ffffff;
}</style><link rel="icon" href="https://wrappixel.com/wp-content/uploads/2016/10/cropped-wrappixel-2-65x65.png" sizes="32x32" /><link rel="icon" href="https://wrappixel.com/wp-content/uploads/2016/10/cropped-wrappixel-2-300x300.png" sizes="192x192" /><link rel="apple-touch-icon-precomposed" href="https://wrappixel.com/wp-content/uploads/2016/10/cropped-wrappixel-2-300x300.png" /><meta name="msapplication-TileImage" content="https://wrappixel.com/wp-content/uploads/2016/10/cropped-wrappixel-2-300x300.png" /><style type="text/css" id="wp-custom-css">#recent-post-blog .col-md-6{width:100%;}
    #recent-post-blog .read-more{
    display: block;
    position: relative;
    margin: 0 auto;
    margin-bottom: 20px;
}
#recent-post-blog.loxlox-recent-product.large .entry-title{ font-size:16px;}

.hero-title{ padding:25px 0px 10px;}
.category-blog .post-meta{
    display:block
}
.category-blog .meta-cat{display:none;}

.category-blog .posted-on{
    float: right;
    margin-top: -30px;
}
.single-post .posted-on{
    float:none;
    margin:0px;
}

@media(max-width:767px) {
.edd-csau-products{
        display:none;
    }

}
#edd_checkout_user_info{
    margin-top:40px;
}

.edd_errors{
    background:red;
    padding:5px 10px;
    color:white;
}</style><style id="loxlox-ctmz-css" type="text/css">.entry-title a:hover,.site-footer a:hover,.site-footer .copyright a:hover,.post-title a:hover,.nav-previous a:hover,.nav-next a :hover{color:#f04e35;}.edd-cart-quantity,.loxlox-recent-product.large .wrapper-content:hover,.loxlox-recent-product:not(.large) .loxlox-price,.archive .type-download .loxlox-price,.download-meta-price-details span,.download-meta-price-details:hover span,.button:hover,.button,.related-post .loxlox-price,.button-submit-icon{background:#f04e35;color:#FFFFFF;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;transition:all .3s ease-in-out;}.widget .read-more:hover{border-color:#f04e35;color:#f04e35;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;transition:all .3s ease-in-out;}.loxlox-recent-testimonial .entry-title:after{background:#f04e35;}body.single-download .hero-title.custom-title .button:hover{background:#f04e35;border-color:#f04e35;color:#FFFFFF;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;transition:all .3s ease-in-out;}</style><meta property="og:locale" content="en_US"/><meta property="og:site_name" content="Wrappixel"/><meta property="og:title" content="Wrappixel"/><meta property="og:url" content="https://wrappixel.com/demos/admin-templates/material-pro/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js"/><meta property="og:type" content="article"/><meta property="og:description" content="We are offering High Quality Bootstrap Admin Templates. Why spend thousands of Dollars if you are getting same quality in $18! with our Premium Admin Templates."/><meta property="og:image" content="https://wrappixel.com/wp-content/uploads/2017/11/computer-hands-web.jpg"/><meta property="article:publisher" content="https://www.facebook.com/wrappixel/"/><meta itemprop="name" content="Wrappixel"/><meta itemprop="description" content="We are offering High Quality Bootstrap Admin Templates. Why spend thousands of Dollars if you are getting same quality in $18! with our Premium Admin Templates."/><meta itemprop="image" content="https://wrappixel.com/wp-content/uploads/2017/11/computer-hands-web.jpg"/><meta name="twitter:title" content="Wrappixel"/><meta name="twitter:url" content="https://wrappixel.com/demos/admin-templates/material-pro/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js"/><meta name="twitter:description" content="We are offering High Quality Bootstrap Admin Templates. Why spend thousands of Dollars if you are getting same quality in $18! with our Premium Admin Templates."/><meta name="twitter:image" content="https://wrappixel.com/wp-content/uploads/2017/11/computer-hands-web.jpg"/><meta name="twitter:card" content="summary_large_image"/><meta name="twitter:site" content="@WrapPixel"/>  <script>!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window,document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '909408915918360');
fbq('track', 'PageView');</script> <noscript> <img height="1" width="1"
src="https://www.facebook.com/tr?id=909408915918360&ev=PageView
&noscript=1"/> </noscript> <style type="text/css">.alert-dismissible{
background: #f04e35!important;
color:white!important;
border-radius: 0px!important;
border:0px;
}
.blck{
    border:1px dashed #2b2b2b;
    background: rgba(0, 0, 0 ,0.25);
    padding:5px 10px;
}</style></head><body class="error404"><div id="page"><header id="masthead" class="site-header" role="banner"><div class="header-inside container"><div class="row"><div class="menu-toggle visible-sm visible-xs col-xs-12"> <span><i class="fa fa-reorder"></i>Menu</span> <span class="menu-close"><i class="fa fa-times"></i>Close Menu</span></div><div class="logo col-md-3"><p class="logo-image"> <a href="https://wrappixel.com/"> <img src="https://wrappixel.com/wp-content/uploads/2017/03/wp-updated-logo.jpg" alt="Top 3 Awesome Looking Free Open-Source Angular Projects" /> </a></p></div><nav role="navigation" class="site-navigation main-navigation col-md-9"><div class="assistive-text"><i class="fa fa-bars"></i> Menu</div><div id="menu" class="menu-main-navigation-container"><ul id="menu-main-navigation" class="menu"><li id="menu-item-15343" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15343"><a href="https://wrappixel.com/templates/category/admin-template/">Admin Templates</a></li><li id="menu-item-199114" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-199114"><a href="https://wrappixel.com/templates/category/ui-kit/">UI Kit</a></li><li id="menu-item-243809" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-243809"><a href="#">Bundles</a><ul class="sub-menu"><li id="menu-item-67213" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67213"><a href="https://wrappixel.com/mega-bundle/">Bootstrap Mega Bundle</a></li><li id="menu-item-243810" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243810"><a href="https://wrappixel.com/mega-bundle-angular/">Angular Mega Bundle</a></li></ul></li><li id="menu-item-15342" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15342"><a href="https://wrappixel.com/templates/category/freebies/">Freebies</a></li><li id="menu-item-311772" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-311772"><a href="https://wrappixel.com/blog/">Blog</a></li><li id="menu-item-221847" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-221847"><a href="https://wrappixel.com/support/">Support</a></li><li class="popup-login menu-item menu-item-type-custom"><a href="#">Login / Register</a></li><li class="current-cart menu-item menu-item-has-children"><a href="https://wrappixel.com/checkout/"><span class="edd-cart-quantity">0</span></a><ul class="sub-menu"><li class="widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p><ul class="edd-cart"><li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li><li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0</span></li><li class="cart_item edd_checkout" style="display:none;"><a href="https://wrappixel.com/checkout/">Checkout</a></li></ul></li></ul></li></ul></div></nav></div></div><div class="hero-title"><div class="hero-title-inside"><div class="container"><h1> Page Not Found</h1></div></div></div></header><div id="login-popup" class="login-popup"><div class="login-body"><h5 class="login-title">Login to WrapPixel <a href="#" class="login-popup-close"><span>&times;</span></a></h5><div class="text-center login-title-desc"><p>You can Login with your Facebook or Google <br/>Account as well.</p></div><div class="login-social"><fieldset id="edd_slg_social_login" class="edd-slg-social-container"><div class="edd-slg-social-wrap"><div class="edd-slg-login-wrapper"> <a title="Connect with Facebook" href="javascript:void(0);" class="edd-slg-social-login-facebook"> <img src="https://wrappixel.com/wp-content/uploads/2017/10/login-facebook.png" alt="Facebook" /> </a></div><div class="edd-slg-login-wrapper"> <a title="Connect with Google+" href="javascript:void(0);" class="edd-slg-social-login-googleplus"> <img src="https://wrappixel.com/wp-content/uploads/2017/10/login-google.png" alt="Google+" /> </a></div><input type="hidden" class="edd-slg-social-gp-redirect-url" id="edd_slg_social_gp_redirect_url" name="edd_slg_social_gp_redirect_url" value="https://accounts.google.com/o/oauth2/auth?client_id=77802509336-i5m87hqat6k3us85lq9p54uqrmhjjm48.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fwrappixel.com%3Feddslg%3Dgoogle&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email"/><div class="edd-slg-clear"></div></div><div class="edd-slg-login-error"></div><div class="edd-slg-login-loader"> <img src="https://wrappixel.com/wp-content/plugins/edd-social-login/includes/images/social-loader.gif" alt="Social Loader"/></div> <input type="hidden" class="edd-slg-redirect-url" id="edd_slg_redirect_url" value="" /></fieldset></div><div id="login-form" class="login-form"><div class="overlay-register-login"></div><form id="login" action="login" method="post"><div class="alert alert-danger alert-login" role="alert"><p class="status"  aria-hidden="true"></p></div> <input type="hidden" id="security" name="security" value="efba3abe83" /><input type="hidden" name="_wp_http_referer" value="/demos/admin-templates/material-pro/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js" /><div class="login-divider"> <span>or</span></div><div class="form-group"> <input type="text" id="username" class="form-control" name="edd_user_login" placeholder="Email Address"></div><div class="form-group"> <input type="password" id="password" class="form-control" placeholder="Password" name="edd_user_pass"></div> <button type="submit" class="btn btn-info btn-block">Login Now</button><div class="login-form-noted"> Not a Member yet? <a id='show-register' href='#' class='link-create'>Create an account ?</a><br/> <a href='https://wrappixel.com/forgot-password/'>Forgot password ?</a></div></form></div><div id="register-form" style="display: none" class="register-form"><div class="overlay-register-login"></div><form id="register" action="register" method="post"><div class="alert alert-danger alert-login" role="alert"><p class="status"  aria-hidden="true"></p></div> <input type="hidden" id="signonsecurity" name="signonsecurity" value="ff98fd0e82" /><input type="hidden" name="_wp_http_referer" value="/demos/admin-templates/material-pro/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js" /><div class="login-divider"> <span>or</span></div><div class="form-group"> <input type="text" class="form-control" id="email" name="email" placeholder="Email Address"></div><div class="form-group"> <input type="password" class="form-control" id="signonpassword" placeholder="Password" name="signonpassword"></div><div class="form-group"> <input type="password" class="form-control" id="password2" placeholder="Repeat Password" name="password2"></div> <button type="submit" class="btn btn-info btn-block">Create Account</button><div class="login-form-noted"> Already have an account? <a id='login-show' href='#' class='link-create'>Login</a><br/></div></form></div><div class="terms-condi">By Sign In or Signup to WrapPixel.com using Facebook, Google or our login/register form, You are agreeing to our <a href="/terms-of-use">Terms of Use</a> and <a href="/privacy-policy">Privacy Policy</a>.</div></div></div><div id="main" class="site-main"><div id="primary" class="content-area"><div id="content" class="site-content container" role="main"><article class="post"><div class="post-content"><div class="post-text"><p>It looks like nothing was found at this location. Try using the navigation menu or the search box to locate the page you were looking for.</p><form method="get" id="searchform" action="https://wrappixel.com/" role="search"> <label for="s" class="assistive-text">Search</label> <input type="text" class="field" name="s" placeholder="Search here..." value="" id="s" /> <input type="submit" class="submit" name="submit" id="searchsubmit" value="Search" /></form><hr/><div class="widget widget_recent_entries"><h2 class="widgettitle">Recent Posts</h2><ul><li> <a href="https://wrappixel.com/top-3-awesome-looking-free-open-source-angular-projects/">Top 3 Awesome Looking Free Open-Source Angular Projects</a></li><li> <a href="https://wrappixel.com/utilizing-bootstrap-framework-to-create-a-website/">Utilizing Bootstrap Framework To Create A Website</a></li><li> <a href="https://wrappixel.com/free-website-templates-for-designers-on-wrappixel/">Free Website Templates For Designers On Wrappixel</a></li><li> <a href="https://wrappixel.com/utilize-awesome-free-premium-react-templates-from-wrap-pixel/">Utilize Awesome Free/Premium React Templates From WrapPixel</a></li><li> <a href="https://wrappixel.com/understand-the-use-of-bootstrap-components/">Understand the Use of Bootstrap Components</a></li></ul></div><hr/><div class="widget widget_categories"><h2 class="widgettitle">Most Used Categories</h2><ul><li class="cat-item cat-item-14"><a href="https://wrappixel.com/category/blog/" title="Beautiful designs for HTMLS , PSDs and wordpress , tips and tricks on design and development, read and subscribe to our design blog">Blog</a> (37)</li><li class="cat-item cat-item-1"><a href="https://wrappixel.com/category/uncategorized/" >Uncategorized</a> (1)</li></ul></div><hr/><div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Try looking in the monthly archives.</p> <label class="screen-reader-text" for="archives-dropdown--1">Archives</label> <select id="archives-dropdown--1" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'><option value="">Select Month</option><option value='https://wrappixel.com/2018/12/'> December 2018</option><option value='https://wrappixel.com/2018/11/'> November 2018</option><option value='https://wrappixel.com/2018/10/'> October 2018</option><option value='https://wrappixel.com/2018/09/'> September 2018</option><option value='https://wrappixel.com/2018/08/'> August 2018</option><option value='https://wrappixel.com/2018/07/'> July 2018</option><option value='https://wrappixel.com/2018/05/'> May 2018</option><option value='https://wrappixel.com/2017/12/'> December 2017</option><option value='https://wrappixel.com/2017/07/'> July 2017</option><option value='https://wrappixel.com/2017/04/'> April 2017</option><option value='https://wrappixel.com/2016/12/'> December 2016</option><option value='https://wrappixel.com/2016/11/'> November 2016</option><option value='https://wrappixel.com/2016/10/'> October 2016</option> </select></div></div></div></article></div></div></div></div><footer class="site-footer"><div class="container"><div class="footer-widgets"><div class="row"><div class="col-md-4"><div id="text-4" class="widget widget_text"><h3 class="widget-title"><span>About WrapPixel</span></h3><div class="textwidget">We at WrapPixel offers Free and Premium Bootstrap Admin Templates, Angular Dashboards and UI Kit. <br><br> WrapPixel founded to reduce the headache, web developers, designers & agencies have to create amazing user interface for their applications and products. Second goal was to save their time and thousands of dollars they have to put in to create stunning designs for their projects.</div></div></div><div class="col-md-3" style="margin-top: 60px; padding-left: 50px;"><h4>Total Customers</h4><h2><b>101,942</b></h2><br/><h4>Total Downloads</h4><h2><b>166,255</b></h2><br/></div><div class="col-md-5"><div id="mc4wp_form_widget-4" class="widget widget_mc4wp_form_widget"><h3 class="widget-title"><span>Want More Freebies ? / Subscribe</span></h3><script>(function() {
    if (!window.mc4wp) {
        window.mc4wp = {
            listeners: [],
            forms    : {
                on: function (event, callback) {
                    window.mc4wp.listeners.push({
                        event   : event,
                        callback: callback
                    });
                }
            }
        }
    }
})();</script><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-72" method="post" data-id="72" data-name="Subscribe to our newsletter!" ><div class="mc4wp-form-fields"><p> <input type="email" name="EMAIL" placeholder="enter email address" required /> <span class="button-submit-icon"> <input type="submit" value="Go" /> </span></p></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1545661865" /><input type="hidden" name="_mc4wp_form_id" value="72" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form></div><div id="loxlox_connect_social-3" class="widget loxlox_connect_social"><div class="loxlox-social-connect"><ul><li class="facebook"> <a href="https://www.facebook.com/wrappixel" target="_blank"> <i class="fa fa-facebook"></i> </a></li><li class="google-plus"> <a href="https://plus.google.com/102672270014738976843" target="_blank"> <i class="fa fa-google-plus"></i> </a></li><li class="twitter"> <a href="https://twitter.com/wrappixel" target="_blank"> <i class="fa fa-twitter"></i> </a></li></ul></div></div><div id="text-5" class="widget widget_text"><div class="textwidget">Secure payment : <img src="https://wrappixel.com/demos/images/payment-options-we-have.jpg"/></div></div></div></div></div><div class="footer-copy"><div class="row"><nav class="footer-navigation col-md-8" role="navigation"><div class="menu-footer-container"><ul id="menu-footer" class="menu"><li id="menu-item-304999" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-304999"><a href="https://wrappixel.com/about-us/">About Us</a></li><li id="menu-item-36698" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36698"><a href="https://wrappixel.com/license/">License</a></li><li id="menu-item-36699" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36699"><a href="https://wrappixel.com/privacy-policy/">Privacy Policy</a></li><li id="menu-item-66746" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-66746"><a href="https://wrappixel.com/affiliate-area/">Affiliate</a></li><li id="menu-item-206854" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-206854"><a href="https://wrappixel.com/support/">Support</a></li><li id="menu-item-276844" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-276844"><a href="https://wrappixel.com/terms-of-use/">Terms</a></li><li id="menu-item-311763" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-311763"><a href="https://wrappixel.com/contact-us/">Contact us</a></li></ul></div></nav><div class="copyright col-md-4"><div class="site-info"> © 2018 wrappixel.com</div></div></div></div></div></footer>  <script type="text/javascript">window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
    d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//v2.zopim.com/?4gucOY1MlvrcvUVJ9GClgI5JHhmy8CFq';z.t=+new Date;$.
    type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');</script><script>$zopim( function() {
})</script><div id="edd-free-downloads-modal" class="edd-free-downloads-hidden"><h3 class="title-share">Thanks For choosing Wrappixel</h3><p class="desc-share">Click on Download Button to <span>Get Package</span></p><form id="edd_free_download_form" method="post"><p style="display: none"> <label for="edd_free_download_email2" class="edd-free-downloads-label">Email Address <span class="edd-free-downloads-required">*</span></label> <input type="text" name="edd_free_download_email" id="edd_free_download_email2" class="edd-free-download-field" placeholder="Email Address" value="" /></p> <input type="hidden" name="edd_free_download_check" value="" /> <input type="hidden" id="edd_free_download_nonce" name="edd_free_download_nonce" value="26ddde4a93" /><input type="hidden" name="_wp_http_referer" value="/demos/admin-templates/material-pro/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js" /><div class="edd-free-download-errors"><p id="edd-free-download-error-email-required"><strong>Error:</strong> Please enter a valid email address</p><p id="edd-free-download-error-email-invalid"><strong>Error:</strong> Invalid email</p><p id="edd-free-download-error-fname-required"><strong>Error:</strong> Please enter your first name</p><p id="edd-free-download-error-lname-required"><strong>Error:</strong> Please enter your last name</p><p id="edd-free-download-error-username-required"><strong>Error:</strong> Please enter a username</p><p id="edd-free-download-error-password-required"><strong>Error:</strong> Please enter a password</p><p id="edd-free-download-error-password2-required"><strong>Error:</strong> Please confirm your password</p><p id="edd-free-download-error-password-unmatch"><strong>Error:</strong> Password and password confirmation do not match</p></div> <input type="hidden" name="edd_action" value="free_download_process" /> <input type="hidden" name="edd_free_download_id"/> <button name="edd_free_download_submit" class="edd-free-download-submit edd-submit button blue"><span>Download Now</span></button></form></div><div id="fb-root"></div><script>(function() {function addEventListener(element,event,handler) {
if(element.addEventListener) {
    element.addEventListener(event,handler, false);
} else if(element.attachEvent){
    element.attachEvent('on'+event,handler);
}
}function maybePrefixUrlField() {
    if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
        this.value = "http://" + this.value;
    }
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
    for( var j=0; j < urlFields.length; j++ ) {
        addEventListener(urlFields[j],'blur',maybePrefixUrlField);
    }
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

    /* add placeholder & pattern to all date fields */
    var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
    for(var i=0; i<dateFields.length; i++) {
        if(!dateFields[i].placeholder) {
            dateFields[i].placeholder = 'YYYY-MM-DD';
        }
        if(!dateFields[i].pattern) {
            dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
        }
    }
}

})();</script><script type='text/javascript' src='https://wrappixel.com/wp-includes/js/jquery/jquery.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-includes/js/jquery/jquery-migrate.min.js'></script> <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js'></script> <script type='text/javascript'>var ajax_auth_object = {"ajaxurl":"https:\/\/wrappixel.com\/wp-admin\/admin-ajax.php","redirecturl":"","redirecttoticketpageurl":"https:\/\/wrappixel.com\/submit-ticket\/","loadingmessage":"Sending user info, please wait..."};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/js/login-register.js'></script> <script type='text/javascript'>var wpcf7 = {"apiSettings":{"root":"https:\/\/wrappixel.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/contact-form-7/includes/js/scripts.js'></script> <script type='text/javascript'>var edd_scripts = {"ajaxurl":"https:\/\/wrappixel.com\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"paypalexpress","redirect_to_checkout":"1","checkout_page":"https:\/\/wrappixel.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js'></script> <script type='text/javascript' src='//www.paypalobjects.com/api/checkout.js' async'></script> <script type='text/javascript'>jQuery(document).ready(function($) {
    if ( !$('select#edd-gateway, input.edd-gateway').length && parseFloat( $('.edd_cart_total .edd_cart_amount').data('total') ) > 0 ) {
        inContextSetup( 'setup' );
    }
if ( edd_scripts.is_checkout == '1' && $('select#edd-gateway, input.edd-gateway').length && parseFloat( $('.edd_cart_total .edd_cart_amount').data('total') ) > 0 ) {
    if ( $('select#edd-gateway, input.edd-gateway').val() == 'paypalexpress' ) {
        setTimeout( function() {
            inContextSetup( 'reset' );
        }, 1500);
    }
}
$('select#edd-gateway, input.edd-gateway').change( function (e) {
    if ( $(this).val() == 'paypalexpress' ) {
        setTimeout( function() {
            inContextSetup( 'reset' );
        }, 1500);
    }
});
function inContextSetup( method ) {
    if ( ! $('#edd-purchase-button').length ) {
        setTimeout( function() {
            inContextSetup( method );
        }, 500);
        return;
    }
    var options = {
        buttons: ['edd-purchase-button'],
        environment: 'production',
        condition: function () {
            var valid = true;
            if ($('#edd-email').val() == '') {
                valid = false;
            }
            $('#edd_purchase_form input.required').each(function() {
                if($(this).val() == '') {
                    valid = false;
                }
            });

            if($('#edd_agree_to_terms').length) {
                if (!$('#edd_agree_to_terms').is(':checked')) {
                    valid = false;
                }
            }
            return valid;
        }
    };
    if ( method == 'setup' ) {
        window.paypalCheckoutReady = function () {
            paypal.checkout.setup( 'D9U8VCD8R4VGN', options );
        }
    }
    else if ( method == 'reset') {
        paypal.checkout.setup( 'D9U8VCD8R4VGN', options );
    }
}
});</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/edd-free-downloads-master/assets/js/isMobile.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/edd-free-downloads-master/assets/js/jBox/Source/jBox.min.js'></script> <script type='text/javascript'>var edd_free_downloads_vars = {"close_button":"overlay","user_registration":"false","require_name":"false","download_loading":"Please Wait... ","download_label":"Download Now","modal_download_label":"Download Now","has_ajax":"1","ajaxurl":"https:\/\/wrappixel.com\/wp-admin\/admin-ajax.php","mobile_url":"\/demos\/admin-templates\/material-pro\/assets\/plugins\/jquery-asColorPicker-master\/libs\/jquery-asGradient.js?edd-free-download=true","form_class":"edd_purchase_submit_wrapper","bypass_logged_in":"true","is_download":"false","loading_text":"Loading..."};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/edd-free-downloads-master/assets/js/edd-free-downloads.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-includes/js/hoverIntent.min.js'></script> <script type='text/javascript'>var checkout_masonry_js_vars = {"load_masonry":""};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout/js/checkout.js'></script> <script type='text/javascript'>var checkout_load_js_vars = {"load_sticky":""};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout/js/edd.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/js/jquery.hashchange.min.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/js/jquery.easytabs.min.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/js/sticky-kit.min.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-content/themes/checkout-child-latest/assets/js/child.js'></script> <script type='text/javascript' src='https://wrappixel.com/wp-includes/js/wp-embed.min.js'></script> <script type='text/javascript' src='https://connect.facebook.net/en_US/all.js?#xfbml=1&#038;appId=127988287842860'></script> <script type='text/javascript'>var EDDSlgFbInit = {"app_id":"127988287842860"};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/edd-social-login/includes/js/edd-slg-fbinit.js'></script> <script type='text/javascript'>var EDDSlg = {"ajaxurl":"https:\/\/wrappixel.com\/wp-admin\/admin-ajax.php","fbappid":"127988287842860","fberror":"","gperror":"","lierror":"1","twerror":"1","yherror":"1","fserror":"1","wlerror":"1","vkerror":"1","insterror":"1","amazonerror":"1","paypalerror":"1","fberrormsg":"<span>Please enter Facebook API Key & Secret in settings page.<\/span>","gperrormsg":"<span>Please enter Google+ Client ID & Secret in settings page.<\/span>","lierrormsg":"<span>Please enter LinkedIn API Key & Secret in settings page.<\/span>","twerrormsg":"<span>Please enter Twitter Consumer Key & Secret in settings page.<\/span>","yherrormsg":"<span>Please enter Yahoo API Consumer Key, Secret & App Id in settings page.<\/span>","fserrormsg":"<span>Please enter Foursquare API Client ID & Secret in settings page.<\/span>","wlerrormsg":"<span>Please enter Windows Live API Client ID & Secret in settings page.<\/span>","vkerrormsg":"<span>Please enter VK API Client ID & Secret in settings page.<\/span>","insterrormsg":"<span>Please enter Instagram API Client ID & Secret in settings page.<\/span>","socialloginredirect":"https:\/\/wrappixel.com\/wp-login.php?edd_slg_social_login=1&eddslgnetwork=twitter","userid":"","amazonerrormsg":"<span>Please enter Amazon API Key & Secret in settings page.<\/span>","paypalerrormsg":"<span>Please enter Paypal API Key & Secret in settings page.<\/span>"};</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/edd-social-login/includes/js/edd-slg-public.js'></script> <script type='text/javascript'>var mc4wp_forms_config = [];</script> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min.js'></script> <!--[if lte IE 9]> <script type='text/javascript' src='https://wrappixel.com/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js'></script> <![endif]--> <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-85622565-1', 'auto');
ga('send', 'pageview');</script>  <script>jQuery(document).ready(function(){
jQuery('.edd-free-downloads-direct-download-link').click(function() {
    var p_id=jQuery("#single_dl_id").val();
    //alert(p_id);

    jQuery.ajax({
        type: "POST",
        url: "https://wrappixel.com/wp-content/themes/checkout-child-latest/count_function.php",
        data: { id: p_id },
        success:function(resp) {
            // alert( "Hello! " + resp );
            //return false;
        }
    });
});

});</script> </body></html>